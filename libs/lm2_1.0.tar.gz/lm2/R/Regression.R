lm2<-function(input,response,fit="OLS",df=NULL,CV=FALSE,cvScale=FALSE,lambda=NULL){
  #init
  yhat=c()
  beta=c()
  betaMat=c()
  yhatMat=c()
  RSS=c()
  errorVector=c()
  DoF=c()
  stdDev=c()
  sigma2=c() #linear regression
  varBeta=c() #linear regression

  if(fit=="OLS"){out=LR(input,response)}
  if(fit%in%c("LAR","Lasso","IFSR")){out=LAR(input,response,type=fit,CV=CV,df=df,
                                             cvScale=cvScale)}
  if(fit=="Subset"){out=SubsetSelect(input,response,size=df,CV=CV,cvScale=cvScale)}
  if(fit=="Ridge"){out=Ridge(input,response,Lambdas=lambda,df=df,CV=CV,cvScale=cvScale)}
  if(fit=="PCR"){out=PCR(input,response,df=df,CV=CV,cvScale=cvScale)}
  if(fit=="PLS"){out=PLS(input,response,df=df,CV=CV,cvScale=cvScale)}
  yhat=out$yhat
  beta=out$beta
  if(fit != "OLS"){
    yhatMat=out$yhatMat
    betaMat=out$betaMat
    errorVector=out$errorVector
    stdDev=out$stdDev
    DoF=out$DoF
    RSS=out$RSS
    l1=list(yhat=yhat,beta=beta,RSS=RSS,yhatMat=yhatMat,betaMat=betaMat,
                errorVector=errorVector,stdDev=stdDev,DoF=DoF)
    if(fit%in%c("Subset","LAR")){
      l1$varList=out$varList
      
    }
  }
  if(fit=="OLS"){
    sigma2=out$sigma2
    varBeta=out$varBeta
    l1=list(yhat=yhat,beta=beta,sigma2=sigma2,varBeta=varBeta)
  }
  return(l1)
}

#least squares use weight vector in case of duplicate observations
LR<-function(input,response){
  X=input
  Y=response
  yhat=c()
  X=cbind(1,X)
  X=as.matrix(X)
  beta=solve(t(X)%*%X)%*%t(X)%*%Y
  yhat=X%*%beta
  sigma2=(1/(ncol(X)))*sum((response-yhat)^2)
  var_beta=solve(t(X)%*%X)*sigma2
  return(list(yhat=yhat,beta=beta,sigma2=sigma2,varBeta=var_beta))
}

#predictions for any linear model
predictLS<-function(LSModel=NULL,X,beta=NULL){
  if(!is.null(LSModel)){beta=LSModel$beta}
  yhat=as.matrix(cbind(1,X))%*%beta
  return(yhat)
}

#converts degree of freedom into L2 penalty coefficient relatively to a dataset
extractLambdas <- function(X,DoF=NULL){
  s=svd(X)
  dj=s$d
  p=ncol(X)
  if(! is.null(DoF)){range=DoF}
  else(range=seq(0,p,0.25))
  N=length(range)
  Lambdas=vector(length = N)
  Lambda1=0#initialize lambda=0
  for (i in 1:N){
    k=range[N-i+1]
    Lambda=Lambda1
    d_lambda=sum(dj^2/(dj^2+Lambda))-k
    d_lambda_prime=-sum(dj^2/((dj^2+Lambda)^2))
    Lambda1=Lambda-d_lambda/d_lambda_prime
    while(abs(d_lambda)>0.0001){
      Lambda=Lambda1
      d_lambda=sum(dj^2/(dj^2+Lambda))-k
      d_lambda_prime=-sum(dj^2/((dj^2+Lambda)^2))
      Lambda1=Lambda-d_lambda/d_lambda_prime
    }
    Lambdas[i]=Lambda1
  }
  return(Lambdas)
}

#Select best subset with regards a loss criterion by cross validation
SubsetSelect <- function(Input,Response,size=NULL,CV=FALSE,cvScale=TRUE){
  
  #init parameters:
  errorVector=c()#CV errors
  betaMat=c()#in case no DoF or shrinkage will return a matrix of all coefficients else empty
  beta=c()#in case no DoF or shrinkage will return beta coefficient else will return beta which give lowest error
  error=c()#RSS related to beta
  yhat=c()#training prediction
  varList=c()#in case no DoF or shrinkage empty, else will return variables which yield lowest RSS
  yhat0=c()
  modelF=FALSE#if TRUE, returns the best model
  stdDev=c()#standard deviations for CV
  DoF=c()

  if(!is.null(size)){q=floor(size)}
  if(is.null(size)){
    q=ncol(Input)
    modelF=TRUE
  }
  if(!CV){
    Input=as.matrix(Input)
    N=nrow(Input)
    p=ncol(Input)
    DoF=0:p
    out=subsetfit(Input,Response,q=q,modelFit = modelF)
    beta=out$beta
    RSS=out$RSS
    betaMat=out$betaMat
    errorVector=out$errorVector
    yhat=predictLS(X=Input,beta=beta)
    varList=which(beta[-1]!=0)
  }
  if(CV){
    source("D:/RProject/toolkits/ModelAssessment&Selection.R")
    Input=as.matrix(Input)
    N=nrow(Input)
    p=ncol(Input)
    DoF=0:p
    for (k in 1:(p+1)){
      out=crossValidate(Input,Response,type="Subset",scaleInputs=cvScale,scaleType="Standardize",complexity=DoF[k])
      errVector=out$errorVector
      stdDev[k]=out$stdDev
      errorVector[k]=mean(errVector)
    }
    j0=which.min(errorVector)-1
    if(!cvScale){
      Input=ScaleData(Input,Response,type = "Standardize")$train
    }
    out00=subsetfit(Input,Response,q = j0)
    beta=out00$beta
    yhat=predictLS(X=Input,beta=beta)
    error=mean((yhat-Response)^2)
    varList=which(beta[-1]!=0)
  }

  return(list(yhat=yhat,beta=beta,RSS=error,betaMat=betaMat,varList=varList,
              errorVector=errorVector,stdDev=stdDev,DoF=DoF))
}

#Select best subset with a given size constraint
subsetfit<-function(Input,Response,q,modelFit=FALSE){
  
  #init parameters
  Input=as.matrix(Input)
  p=ncol(Input)
  N=nrow(Input)
  betaMat=matrix(0,nrow=p+1);betaMat[1,]=mean(Response)
  beta=rep(0,length=p+1);beta[1]=mean(Response)
  RSS=0
  errorVector=rep(0,length=q+1)
  yhat=0
  featList=0
  
  if(q==0){
    yhat=mean(Response)
    RSS=mean((yhat-Response)^2)
  }
  if(q>0){
    count=q
    if(modelFit){
      count=1
      errorVector=rep(0,length=q+1)
      errorVector[1]=mean((Response-mean(Response))^2)
    }
    for(k in count:q){
      set=combn(p,k)
      Nk=ncol(set)
      error=rep(1,length=Nk)
      beta0=matrix(0,ncol=Nk,nrow=k)
      yhat=mean(Response)
      for(j in 1:Nk){
        featList0=set[,j]
        X=Input[,featList0]
        beta0[,j]=solve(t(X)%*%X)%*%t(X)%*%(Response-mean(Response))
        if(k==1){yhat0=beta0[,j]*X+mean(Response)}
        if(k>1){yhat0=X%*%beta0[,j]+mean(Response)}
        error[j]=mean((yhat0-Response)^2)
      }
      j0=which.min(error)
      featList=set[,j0]
      RSS=error[j0]
      beta[featList+1]=beta0[,j0]
      if(modelFit){
        errorVector[k+1]=RSS
        betaMat=cbind(betaMat,beta)
      }
    }
    if(modelFit){
      j0=which.min(errorVector)
      RSS=min(errorVector)
      beta=betaMat[,j0]
      featList=which(beta[-1]!=0)
    }
    yhat=cbind(1,Input)%*%beta
  }
  return(list(beta=beta,RSS=RSS,yhat=yhat,varList=featList,errorVector=errorVector,betaMat=betaMat))
}

#3 model selection algorithms: 
#Least Angle Regression, Incremental Forward Stagewise Regression, Lasso
#If no cross validation, must centralize & unit norm for covariates
#If cross validation: data scaling will be done in the CV loop
LAR<-function(Input,resp,type="LAR",df=NULL,CV=FALSE,cvScale=TRUE){
  
  #init parameters:
  errVector=c()#CV errors
  betaMat=c()#in case no DoF or shrinkage will return a matrix of all coefficients else empty
  beta=c()#in case no DoF or shrinkage will return beta coefficient else will return beta which give lowest error
  error=c()#RSS related to beta
  yhat=c()#training prediction
  varList=c()#in case no DoF or shrinkage empty, else will return variables which yield lowest RSS
  yhat0=c()
  modelF=FALSE#if TRUE, will the best model
  stdDev=c()#standard deviations for CV
  DoF=c()
  
  if(!is.null(df)){size=min(floor(df),ncol(Input))}
  if(is.null(df)){
    size=ncol(Input)
    modelF=TRUE
    }
  if(!CV){
    out=LARfit(Input,resp,q=size,modelFit = modelF)
    beta=out$beta
    error=out$RSS
    betaMat=out$betaMat
    errVector=out$errorVector
    yhat0=out$yhat0
    yhat=predictLS(X=Input,beta=beta)
  }
  if(CV & is.null(df)){
    source("D:/RProject/toolkits/ModelAssessment&Selection.R")
    DoF=seq(0,size)
    out=crossValidate(Input,resp,type=type,scaleInputs=cvScale,scaleType="Unit",complexity=DoF,NbreCV = 10)
    errVector=out$errorVector
    stdDev=out$stdDevVector
    error=min(errVector)
    bestSize=which.min(error)
    if(cvScale){Input=ScaleData(Input,resp,type = "Unit")$train}
    out00=LARfit(Input,resp,bestSize)
    beta=out00$beta
    yhat=predictLS(X=Input,beta=beta)
  }
  varList=which(beta[-1] !=0)

  return(list(yhat=yhat,beta=beta,RSS=error,betaMat=betaMat,varList=varList,
              errorVector=errVector,stdDev=stdDev,DoF=DoF))
}

#LAR fit
LARfit<-function(Input,resp,q,modelFit=FALSE,type="LAR"){
  resp0=resp-mean(resp)
  p=ncol(Input)
  N=nrow(Input)
  betaMat=matrix(0,ncol=q+1,nrow=p+1)
  betaMat[1,]=mean(resp)
  errorVector=rep(0,length=q+1)
  yhatMat=matrix(0,ncol=q+1,nrow=N)
  T_beta=c()
  S_beta=c()
  #q=0
  errorVector[1]=mean((resp-mean(resp))^2)
  yhatMat[,1]=mean(resp)
  
  if(q>0){
    #iteration 0
    yhat=0
    res=resp0-yhat

    for(i in 1:q){
      corrvector=t(Input)%*%res#covariates corrlation with residual
      if(i==1){#init C & active set
        C=max(abs(corrvector))
        Aj=which(abs(corrvector)==C)
      }

      sj=sign(corrvector[Aj])
      XA=as.matrix(Input[,Aj])%*%diag(sj)
      vv=c(10,20,30,40)
      if(ncol(XA)==1){GA=1}
      if(ncol(XA)>1){GA=solve(t(XA)%*%XA)}
      AA=1/sqrt(sum(GA))
      if(ncol(XA)==1){wA=1;uA=XA}
      if(ncol(XA)>1){
        wA=AA*as.matrix(rowSums(GA))
        uA=XA%*%wA #equi-angular vector
      }
      a=t(Input)%*%uA
      if(i<p){
        Ac=which(! seq(1:p) %in% Aj)
        gammaL=apply(as.matrix(Ac),1,function(x){
          tt=c((C-corrvector[x])/(AA-a[x]),(C+corrvector[x])/(AA+a[x]))
          vv=min(tt[tt>0])
          return(vv)
        })
        gamma=min(gammaL)
      }
      if(i==p){gamma=C/AA}
      betaMat[Aj+1,i+1]=betaMat[Aj+1,i]+sj*gamma*wA
      yhat=yhat+gamma*uA
      res=resp0-yhat
      T_beta=c(T_beta,sum(abs(betaMat[,i+1])))
      S_beta=c(S_beta,sum(res^2))
      yhatMat[,i+1]=yhat
      errorVector[i+1]=mean(res^2)
      if(i<q){#update C & active set for next step
        j0=Ac[which.min(gammaL)]
        Aj=c(Aj,j0)
        C=C-gamma*AA
      }
    }
  }
  if(modelFit){regSize=which.min(errorVector)}
  if(!modelFit){regSize=q+1}
  
  beta=betaMat[,regSize]
  yhat0=yhatMat[,regSize]
  RSS=errorVector[regSize]
  
  return(list(beta=beta,RSS=RSS,yhat0=yhat0,errorVector=errorVector,betaMat=betaMat,T_beta=T_beta,S_beta=S_beta))
}

#Ridge selection
Ridge <-function(Input,resp,Lambdas=NULL,df=NULL,CV=FALSE,cvScale=TRUE){
  
  #init parameters
  errorVector=c()
  RSS=c()
  yhat=c()
  beta=as.matrix(rep(0,length=ncol(Input)+1))
  betaMat=matrix(0,nrow = ncol(Input)+1)
  rownames(betaMat)=c("intercept",colnames(Input))
  stdDev=c()
  DoF=c()
  
  if(!is.null(Lambdas) | !is.null(df)){
    if(!is.null(Lambdas)){ll=Lambdas}
    if(!is.null(df) & is.null(Lambdas)){ll=extractLambdas(Input,DoF = df)}
    out=ridgefit(Input,resp,lambda = ll)
    RSS=out$RSS
    beta=out$beta
    yhat=out$yhat
  }
  
  if(is.null(df) & is.null(Lambdas)){
    lambda_vector=extractLambdas(Input)
    L=length(lambda_vector)
    N=nrow(Input)
    p=ncol(Input)
    Input=as.matrix(Input)
    for (i in 1:L){
      Lambda=lambda_vector[i]
      if(CV){
        source("D:/RProject/toolkits/ModelAssessment&Selection.R")
        out=crossValidate(Input,resp,type = "Ridge",complexity = Lambda,scaleInputs = cvScale,scaleType ="Standardize")
        errorVector[i]=mean(out$errorVector)
        stdDev[i]=out$stdDev
      }
      out0=ridgefit(Input,resp,Lambda)
      if(!CV){errorVector[i]=out0$RSS}
      betaMat=cbind(betaMat,out0$beta)
      Hat=Input%*% solve(t(Input)%*%Input + Lambda * diag(p)) %*% t(Input)
      DoF[i]=sum(diag(Hat))
    }
    betaMat=betaMat[,-1]
    beta=betaMat[,which.min(errorVector)]
    RSS=min(errorVector)
    yhat=predictLS(X = Input,beta = beta)
  }
  
  return(list(yhat=yhat,beta=beta,RSS=RSS,betaMat=betaMat,errorVector=errorVector,
              stdDev=stdDev,DoF=DoF))
}

#Builds a ridge model given lambda or df
ridgefit <-function(Input,resp,lambda){
  X=as.matrix(Input)
  resp0=resp-mean(resp)
  mat=solve(t(X)%*%X+lambda*diag(ncol(X)))
  beta=c(mean(resp),mat%*%t(X)%*%resp0)
  yhat=as.matrix(cbind(1,X))%*%beta
  RSS=mean((resp-yhat)^2)
  return(list(yhat=yhat,beta=beta,RSS=RSS))
}

#selects PCA reduction by CV
PCR <- function(Input,Response,df=NULL,CV=FALSE,cvScale=TRUE){
  
  #init parameters:
  errVector=c()#CV errors
  betaMat=c()#in case no DoF or shrinkage will return a matrix of all coefficients else empty
  beta=c()#in case no DoF or shrinkage will return beta coefficient else will return beta which give lowest error
  error=c()#RSS related to beta
  yhat=c()#training prediction
  varList=c()#in case no DoF or shrinkage empty, else will return variables which yield lowest RSS
  yhat0=c()
  modelF=FALSE#if TRUE, will the best model
  stdDev=c()#standard deviations for CV
  DoF=c()
  
  if(!is.null(df)){q=floor(df)}
  if(is.null(df)){
    q=ncol(Input)
    modelF=TRUE
  }
  if(!CV){
    out=PCRfit(Input,Response,q,modelFit = modelF)
    beta=out$beta
    RSS=out$RSS
    betaMat=out$betaMat
    errorVector=out$errorVector
    yhat=predictLS(X=Input,beta=beta)
    DoF=0:q
  }
  if(CV){
    source("D:/RProject/toolkits/ModelAssessment&Selection.R")
    DoF=0:ncol(Input)
    out=crossValidate(Input,Response,type="PCR",scaleInputs=cvScale,scaleType="Standardize",complexity = DoF)
    errorVector=out$errorVector
    stdDev=out$stdDevVector
    error=min(errorVector)
    bestSize=which.min(error)-1
    if(cvScale){Input=ScaleData(Input,Response,type = "Standardize")$train}
    out00=PCRfit(Input,Response,bestSize)
    beta=out00$beta
    yhat=predictLS(X=Input,beta=beta)
  }
  return(list(yhat=yhat,beta=beta,RSS=error,betaMat=betaMat,errorVector=errorVector,
              stdDev=stdDev,DoF=DoF))
}

#prediction function for PCR. Prediction can be done 02 ways:
#provide the best selected model OR training data + subset size
PCRfit <- function(Input,resp,q,modelFit=FALSE){
  
  resp0=resp-mean(resp)
  Input=as.matrix(Input)
  p=ncol(Input)
  N=nrow(Input)
  betaMat=matrix(0,ncol=q+1,nrow=p+1)
  betaMat[1,]=mean(resp)
  errorVector=rep(0,length=q+1)
  RSS=c()
  beta=c()
  yhat=c()
  
  pca=PCA(Input)
  Z=pca$Z;V=pca$V;D=pca$D
  if(q==0){
    RSS=mean((resp-mean(resp))^2)
    beta=betaMat[,1]
  }
  if(q>0){
    thetaHat=rep(0,length=q)
    if(modelFit){errorVector[1]=mean((resp-mean(resp))^2)}
    for (j in 1:q){
      thetaHat[j]=sum(t(Z[,j])%*%resp0)/D[j,j]
      for (i in j:q){
        betaMat[2:(p+1),i+1]=betaMat[2:(p+1),i+1]+thetaHat[j]*V[,j]
      }
      if(modelFit){
        yhat=predictLS(X=Input,beta = betaMat[,i+1])
        errorVector[j+1]=mean((yhat-resp)^2)
      }
    }
    if(modelFit){j0=which.min(errorVector)}
    if(!modelFit){j0=q+1}
    beta=betaMat[,j0]
    RSS=errorVector[j0]
    yhat=predictLS(X = Input,beta = beta)
  }
  return(list(beta=beta,RSS=RSS,yhat=yhat,errorVector=errorVector,betaMat=betaMat))
}

#select best PLS by CV
PLS <- function(Input,resp,df=NULL,CV=FALSE,cvScale=TRUE){
  
  #init parameters:
  errVector=c()#CV errors
  betaMat=c()#in case no DoF or shrinkage will return a matrix of all coefficients else empty
  beta=c()#in case no DoF or shrinkage will return beta coefficient else will return beta which give lowest error
  error=c()#RSS related to beta
  yhat=c()#training prediction
  varList=c()#in case no DoF or shrinkage empty, else will return variables which yield lowest RSS
  yhat0=c()
  stdDev=c()#standard deviations for CV
  DoF=c()
  yhatMat=c()
  if(!is.null(df)){q=min(floor(df),ncol(Input))}
  if(is.null(df)){
    q=ncol(Input)
    modelF=TRUE
  }
  if(!CV){
    out=PLSfit(Input,resp,q)
    beta=out$Beta
    RSS=out$RSS
    betaMat=out$betaMat
    errorVector=out$errorVector
    yhatMat=out$yhatMat
    yhat=predictLS(X=Input,beta=beta)
    DoF=0:q
  }
  if(CV){
    source("D:/RProject/toolkits/ModelAssessment&Selection.R")
    DoF=0:q
    out=crossValidate(Input,resp,type="PLS",scaleInputs=cvScale,
                      scaleType="Standardize",complexity = DoF)
    errorVector=out$errorVector
    stdDev=out$stdDevVector
    error=min(errorVector)
    bestSize=which.min(error)-1
    betaMat=out$betaMat
    if(cvScale){Input=ScaleData(Input,resp,type = "Standardize")$train}
    out00=PLSfit(Input,resp,bestSize)
    beta=out00$Beta
    yhat=predictLS(X=Input,beta=beta)
  }
  return(list(yhat=yhat,beta=beta,yhatMat=yhatMat,RSS=error,betaMat=betaMat,errorVector=errorVector,stdDev=stdDev,DoF=DoF))
}

#PLS
PLSfit<- function(Input,resp,q){
  
  resp0=resp-mean(resp)
  Input=as.matrix(Input)
  p=ncol(Input)
  N=nrow(Input)
  betaMat=matrix(0,ncol=q+1,nrow=p+1)
  betaMat[1,]=mean(resp)
  errorVector=rep(0,length=q+1)
  yhatMat=matrix(0,nrow=N,ncol=q+1)
  yhatMat[,1]=mean(resp)
  Beta=c()
  RSS=c()
  km=matrix()
  Km=diag(p)
  
  if(q==0){
    Beta=betaMat[,1]
    RSS=mean((resp-mean(resp))^2)
  }
  if(q>0){
    Xj=Input
    RSS[1]=mean((resp-mean(resp))^2)
    for(j in 1:q){
      u=t(Xj)%*%resp0
      z=Xj%*%u
      Z2=sum(z^2)
      theta=sum(z*resp)/Z2
      yhatMat[,j+1]=yhatMat[,j]+theta*z
      betaMat[2:(p+1),j+1]=betaMat[2:(p+1),j]+theta*Km%*%Km%*%t(Xj)%*%resp0
      km=diag(p)-u%*%t(u)%*%t(Xj)%*%Xj/Z2
      Xj=Xj%*%km
      Km=Km%*%km
      RSS[j+1]=mean((resp-yhatMat[,j+1])^2)
    }
    Beta=betaMat[,which.min(RSS)]
  }
  return(list(yhatMat=yhatMat,betaMat=betaMat,RSS=RSS,Beta=Beta))
}

