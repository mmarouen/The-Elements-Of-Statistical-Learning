#PCA transformation
PCA<-function(Input){
  Input=as.matrix(Input)
  decomp=eigen(t(Input)%*%Input,symmetric = TRUE)
  D=diag(decomp$values)
  V=decomp$vectors
  Z=Input%*%V
  varProp=decomp$values/(sum(decomp$values));cumVarProp=cumsum(varProp)
  return(list(Z=Z,V=V,D=D,lamda=decomp$d,varianceProportion=varProp,cumulativeEnergy=cumVarProp))
}

#convert features to nummeric
#NB: in case of an ordinal variable containing K different values,
#the code will replace that variable with (K-1) dummy variables
# toNumeric<-function(X){
#   
#   featMap=lapply(1:ncol(X),function(x) list(type=sapply(X,class)[x][[1]],lev=levels(X[,x])))
#   N=nrow(X)
#   X1=X
#   longCard=NULL
#   for(i in 1:ncol(X)){
#     if(!is.null(featMap[[i]]$lev)){#factor variable
#       if(featMap[[i]]$type[1]=="ordered"){#ordinal
#         levels(X[,i])=seq(length(featMap[[i]]$lev))
#         X1[,i]=as.numeric(as.character(X[,i]))-length(levels(X[,i]))
#       }
#       if(featMap[[i]]$type[1] !="ordered"){#nominal
#         K=length(featMap[[i]]$lev)
#         if(K==2){levels(X[,i])=c(1,-1); X1[,i]=as.numeric(as.character(X[,i]))}
#         if(K>2){#create dummy variables
#           longCard=c(longCard,i)
#           tmp=matrix(0,ncol=K-1,nrow=N)
#           ii=sapply(1:N,function(x) which(X[x,i]==levels(X[,i])))
#           for(j in 1:N){
#             if(ii[j]>1){tmp[j,ii[j]-1]=1}
#           }
#           colnames(tmp)=sapply(1:(K-1),function(x) paste(names(featMap[[i]]$type),x))
#           X1=cbind(X1,tmp)
#         }
#       }
#     }
#   }
#   if(!is.null(longCard)){X1=X1[,-longCard]}
#   return(X1)
# }

#performs several preprocessing operations:
#1.4 types of data scaling: 
#   "standardize": mean=0,sd=1 (in case of test data provided scaling is done using training mean & sd)
#   "normalize": in [0,1] or in [-1,1] ("symm"=TRUE)
#   "unit": covariates have unit norm
#2.center
#3.shuffle lines to avoid prior DB arranging (shuffle=TRUE)
#NB: when 02 input data included, the 2nd is considered testing data.
#in case of scaline, training data mean/sd is applied to test data mean/sd
ScaleData <- function(Input,Response=NULL,InputTest=NULL,ResponseTest=NULL,type=NULL,symm=TRUE,shuffle=FALSE){
  N=nrow(Input)
  means=c()
  stds=c()
  if(! is.null(Response) & shuffle){
    inds=sample(N,N)
    Input=Input[inds,]#avoid DB prior filtering
    Response=Response[inds]
  }
  if((! is.null(InputTest))&(! is.null(ResponseTest))& shuffle){
    N1=nrow(InputTest)
    inds1=sample(N1,N1)
    InputTest=InputTest[inds1,]
    ResponseTest=ResponseTest[inds1]
  }
  if(!is.null(type)){
    #extract only quantitative inputs
    if(ncol(Input)>1){
      cols=!apply(Input,2,is.factor)
      tmp=Input[,cols]
    }
    if(ncol(Input)==1){
      tmp=as.matrix(Input)
      cols=1
    }
    if(type=="Unit"){
      tmp=scale(tmp,TRUE,TRUE)
      means=attr(tmp,"scaled:center")
      stds=attr(tmp,"scaled:scale")
      tmp=apply(tmp,2,function(x) x/sqrt(sum(x^2)))
      Input[,cols]=tmp
      if(! is.null(InputTest)){
        tmp1=as.matrix(InputTest[,cols])
        tmp1=t(apply(tmp1,1,'-', means ))
        tmp1=t(apply(tmp1,1,'/', stds ))
        tmp1=apply(tmp1,2,function(x) x/sqrt(sum(x^2)))
        InputTest[,cols]=as.matrix(tmp1)
      }
    }
    if(type=="Standardize"){#studentized residuals
      tmp=scale(tmp,TRUE,TRUE)
      means=attr(tmp,"scaled:center")
      stds=attr(tmp,"scaled:scale")
      Input[,cols]=tmp
      if(! is.null(InputTest)){
        tmp1=as.matrix(InputTest[,cols])
        tmp1=t(apply(tmp1,1,'-', means ))
        tmp1=t(apply(tmp1,1,'/', stds ))
        InputTest[,cols]=as.matrix(tmp1)
      }
    }
    if(type=="Normalize"){#covariates in range 0,1 or -1,1
      Input[,cols]=apply(tmp,2,function(x) (x-min(x))/(max(x)-min(x)))
      if(! is.null(InputTest)){
        tmp1=InputTest[,cols]
        InputTest[,cols]=apply(tmp1,2,function(x) (x-min(x))/(max(x)-min(x)))
      }
      if(symm){
        Input=2*Input-1
        if(! is.null(InputTest)){InputTest=2*InputTest-1}
      }
    }
  }
  
  return(list(train=Input,respTrain=Response,test=InputTest,respTest=ResponseTest,paramList=list(means=means,stds=stds)))
}

#split a given input & response vector into train/validation/test sets
#split ratio
# splitData<-function(Input,Response,trainRatio=0.6,validationRatio=0.2,testRatio=0.2){
#   N=nrow(Input)
#   trainInds=sample(1:N,size =trainRatio*N ,replace = FALSE)
#   train=Input[trainInds,]
#   yTrain=Response[trainInds]
#   if(validationRatio != 0){
#     validationInds=sample(setdiff(1:N,trainInds),size=validationRatio*N,replace = FALSE)
#     testInds=setdiff(setdiff(1:N,trainInds),validationInds)
#     val=Input[validationInds,]
#     yVal=Response[validationInds]
#     test=Input[testInds,]
#     yTest=Response[testInds]
#   }
#   if(validationRatio==0){
#     val=c();yVal=c()#init
#     testInds=setdiff(1:N,trainInds)
#     test=Input[testInds,]
#     yTest=Response[testInds]
#   }
#   return(list(train=train,yTrain=yTrain,val=val,yVal=yVal,test=test,yTest=yTest))
# }

