#linear classification function
lc<-function(Input,Response,fit="LDA",sub=NULL,alpha=NULL,gamma=NULL,cv=FALSE,cvScale=FALSE){

  ll=list()
  if(fit=="LDA"){
    ll=LinDA(Input,Response)
  }
  if(fit=="QDA"){
    ll=QuaDA(Input,Response)
  }
  if(fit=="RRDA"){
    ll=RRDA(Input,Response,sub=sub,CV = cv,cvScale = cvScale)
  }
  if(fit=="RegDA"){
    ll=RegDA(Input,Response,alpha = alpha,gamma = gamma,CV = cv,cvScale = cvScale)
  }
  ll$fit=fit
  return(ll)
}

lcPredict<-function(Input,model){
  fit=model$fit
  if(fit=="LDA") return(predictLinDA(Input,model))
  if(fit=="QDA") return(predictQuaDA(Input,model))
  if(fit=="RRDA")return(predictRRDA(Input,model))
  if(fit=="RegDA") return(predictRegDA(Input,model))
}

#Linear Indicator Matrix
IndMat<-function(Input,Response,InputTest=NULL){
  Input=as.matrix(Input)
  N=nrow(Input)
  K=length(unique(Response))
  p=ncol(Input)
  resp=as.numeric(Response)
  Y=matrix(0,N,K)
  for (i in 1:N){
    Y[i,resp[i]]=1
  }
  X=cbind(1,Input)
  BETA_hat=solve(t(X)%*%X)%*%t(X)%*%Y
  yHatTrain=X%*%BETA_hat
  yHatTrain=apply(yHatTrain,1,which.max)
  yHatTest=NULL
  if(!is.null(InputTest)){
    InputTest=as.matrix(InputTest)
    X1=cbind(1,InputTest)
    yHatTest=X1%*%BETA_hat
    yHatTest=apply(yHatTest,1,which.max)
  }
  return(list(yHatTrain=yHatTrain,yHatTest=yHatTest,betaMat=BETA_hat))
}
predictIndMat<-function(Input,modIndMat){
  betaMat=outIndMat$betaMat
  X=cbind(1,Input)
  yhatMat=X%*%betaMat
  yhat=apply(yhatMat,1,which.max)
  return(yhat)
}
#LDA classifier
LinDA<- function(Input,Response){
  Input=as.matrix(Input)
  N=nrow(Input)
  K=length(unique(Response))
  classes=as.numeric(levels(as.factor(Response)))
  p=ncol(Input)
  Mu_k=matrix(0,nrow = p,ncol = K)#centroid vectors
  Pi_k=vector(length= K)# a priori probabilities
  sigma=matrix(0,ncol=p,nrow = p)#classes covariance matrix
  for (i in 1:K){
    tmp=Input[Response==classes[i],]
    Pi_k[i]=nrow(tmp)/N
    Mu_k[,i]=colMeans(tmp)
    for(j in 1:nrow(tmp)){
      sigma=sigma+(tmp[j,]-Mu_k[,i])%*%t(tmp[j,]-Mu_k[,i])
    }
  }
  sigma=sigma*(1/(N-K))
  sigmaMinus1=solve(sigma)
  
  #Classification
  deltaTrain=matrix(0,ncol = K,nrow = N)
  for (i in 1:K){
    deltaTrain[,i]=Input%*%sigmaMinus1%*%Mu_k[,i]
    deltaTrain[,i]=deltaTrain[,i]-0.5*t(Mu_k[,i])%*%sigmaMinus1%*%Mu_k[,i]+log(Pi_k[i])
  }
  #prediction
  yHatTrain=apply(deltaTrain,1, which.max)
  return(list(yhat=yHatTrain,sigmaMin1=sigmaMinus1,centroids=Mu_k,Pi_k=Pi_k))
}

predictLinDA<-function(Input,modLinda){
  sigmaMinus1=modLinda$sigmaMin1
  centroidMat=modLinda$centroids
  Pi_k=modLinda$Pi_k
  K=ncol(centroidMat)
  #compute discriminant matrix
  deltaMat=matrix(0,ncol=K,nrow=nrow(Input))
  for(i in 1:K){
    deltaMat[,i]=as.matrix(Input)%*%sigmaMinus1%*%centroidMat[,i]
    deltaMat[,i]=deltaMat[,i]-0.5*t(centroidMat[,i])%*%sigmaMinus1%*%centroidMat[,i]+log(Pi_k[i])
  }
  yHat=apply(deltaMat,1, which.max)
  return(yHat)
}
#QDA classifier
QuaDA<- function(Input,Response){
  Input=as.matrix(Input)
  N=nrow(Input)
  p=ncol(Input)
  K=length(unique(Response))
  classes=as.numeric(levels(as.factor(Response)))
  Mu_k=matrix(0,nrow = p,ncol = K)#centroid vectors
  Pi_k=vector(length= K)# classes a priori
  sigma_k=list()#data covariances matrix per class
  sigmaMinus1_k=list()
  det_k=vector(length = K)
  for (i in 1:K){
    sigma_k[[i]]=matrix(0,ncol=p,nrow = p)
    tmp=Input[Response==classes[i],]
    N0=nrow(tmp)
    Pi_k[i]=N0/N
    Mu_k[,i]=colMeans(tmp)
    for(j in 1:N0){
      sigma_k[[i]]=sigma_k[[i]]+(tmp[j,]-Mu_k[,i])%*%t(tmp[j,]-Mu_k[,i])
    }
    sigma_k[[i]]=(1/(N0-1))*sigma_k[[i]]
    sigmaMinus1_k[[i]]=solve(sigma_k[[i]])
    det_k[i]=det(sigma_k[[i]])
  }
  #discriminant matrix
  deltaTrain=matrix(0,ncol = K,nrow = N)
  for (i in 1:K){
    deltaTrain[,i]=apply(Input,1,function(x) -0.5*t(x-Mu_k[,i])%*%sigmaMinus1_k[[i]]%*%(x-Mu_k[,i]))
    deltaTrain[,i]=deltaTrain[,i]-0.5*log(det_k[i])+log(Pi_k[i])
  }
  #prediction
  yHatTrain=apply(deltaTrain,1,which.max)
  return(list(yhat=yHatTrain,sigmaMinus1_k=sigmaMinus1_k,Mu_k=Mu_k,det_k=det_k,Pi_k=Pi_k))
}
predictQuaDA<-function(Input,modQuaDA){
  #load model parameters
  sigmaMinus1_k=modQuaDA$sigmaMinus1_k
  Mu_k=modQuaDA$Mu_k
  det_k=modQuaDA$det_k
  Pi_k=modQuaDA$Pi_k
  K=length(Pi_k)
  #discriminant matrix
  descrMat=matrix(0,ncol=K,nrow=nrow(Input))
  for(i in 1:K){
    descrMat[,i]=apply(Input,1,function(x) -0.5*t(x-Mu_k[,i])%*%sigmaMinus1_k[[i]]%*%(x-Mu_k[,i]))
    descrMat[,i]=descrMat[,i]-0.5*log(det_k[i])+log(Pi_k[i])
  }
  yHat=apply(descrMat,1,which.max)
  return(yHat)
}

#Regularized discriminant analysis fit
RegDAfit<- function(Input,Response,InputTest=NULL,alpha,gamma){
  Input=as.matrix(Input)
  N=nrow(Input)
  p=ncol(Input)
  K=length(unique(Response))
  classes=as.numeric(levels(as.factor(Response)))
  #init parameters
  Mu_k=matrix(0,nrow = p,ncol = K)#centroid vectors
  Pi_k=vector(length= K)# classes a priori
  sigma=matrix(0,nrow=p,ncol=p)# within class covariance (constant)
  sigma_k=list()#within class covariance
  sigmaHat=matrix(0,ncol=p,nrow = p)
  det_k=vector(length = K)
  #compute parameters
  for (i in 1:K){
    sigma_k[[i]]=matrix(0,ncol=p,nrow = p)
    tmp=Input[Response==classes[i],]
    N0=nrow(tmp)
    Pi_k[i]=N0/N
    Mu_k[,i]=colMeans(tmp)
    for(j in 1:N0){
      sigma_k[[i]]=sigma_k[[i]]+(tmp[j,]-Mu_k[,i])%*%t(tmp[j,]-Mu_k[,i])
      sigma=sigma+(tmp[j,]-Mu_k[,i])%*%t(tmp[j,]-Mu_k[,i])
    }
    sigma_k[[i]]=(1/(N0-1))*sigma_k[[i]]
  }
  sigma=(1/(N-K))*sigma
  sigma2=(1/p)*sum(diag(sigma))
  sigmaHat=gamma*sigma+(1-gamma)*sigma2*diag(p)
  sigmaHat_k=list()
  sigmaHatMin1_k=list()
  for (i in 1:K){
    sigmaHat_k[[i]]=matrix(0,ncol=p,nrow=p)
    sigmaHatMin1_k[[i]]=matrix(0,ncol=p,nrow=p)
    sigmaHat_k[[i]]=alpha*sigma_k[[i]]+(1-alpha)*sigmaHat
    sigmaHatMin1_k[[i]]=solve(sigmaHat_k[[i]])
    det_k[i]=det(sigmaHat_k[[i]])
  }
  #Classification
  deltaTrain=matrix(0,ncol = K,nrow = N)
  for (i in 1:K){
    deltaTrain[,i]=apply(Input,1,function(x) -0.5*t(x-Mu_k[,i])%*%sigmaHatMin1_k[[i]]%*%(x-Mu_k[,i]))
    deltaTrain[,i]=deltaTrain[,i]-0.5*log(det_k[i])+log(Pi_k[i])
  }
  #prediction
  yHatTrain=apply(deltaTrain,1,which.max)
  return(list(yhat=yHatTrain,Mu_k=Mu_k,sigmaHatMin1_k=sigmaHatMin1_k,Pi_k=Pi_k,det_k=det_k))
}
#Regularized discriminant analysis prediction (identical to QDA predictor)
predictRegDA<-function(Input,modeRegDA){
  #load model parameters
  if(!is.null(modeRegDA$modRegda)){modeRegDA=modeRegDA$modRegda}
  sigmaMinus1_k=modeRegDA$sigmaHatMin1_k
  Mu_k=modeRegDA$Mu_k
  det_k=modeRegDA$det_k
  Pi_k=modeRegDA$Pi_k
  K=length(Pi_k)
  #discriminant matrix
  descrMat=matrix(0,ncol=K,nrow=nrow(Input))
  for(i in 1:K){
    descrMat[,i]=apply(as.matrix(Input),1,function(x) -0.5*t(x-Mu_k[,i])%*%sigmaMinus1_k[[i]]%*%(x-Mu_k[,i]))
    descrMat[,i]=descrMat[,i]-0.5*log(det_k[i])+log(Pi_k[i])
  }
  yHat=apply(descrMat,1,which.max)
  return(yHat)
}
#regularized discriminant model selection, if parameters alpha/gamma are given
#then model is computed directly
RegDA<-function(Input,Response,alpha=NULL,gamma=NULL,CV=FALSE,cvScale=FALSE,L=40){
  
  #init parameters:
  error=c()
  errorMat=c()#selection error matrix
  yhat=c()#training prediction
  stderr=c()#standard deviations for CV

  if(!is.null(alpha) & !is.null(gamma)){
    out1=RegDAfit(Input,Response,alpha=alpha,gamma=gamma)
    i0=1
    j0=1
  }
  if(is.null(alpha) | is.null(gamma)){
    if(is.null(alpha)){alpha=seq(0,1,length=L)}
    if(is.null(gamma)){gamma=seq(0,1,length=L)}
    errorMat=matrix(0,ncol=length(gamma),nrow=length(alpha))
    stderr=matrix(0,ncol=length(gamma),nrow=length(alpha))
    for(i in 1:length(alpha)){
      for(j in 1:length(gamma)){
        if(!CV){
          out=RegDAfit(Input,Response,alpha=alpha[i],gamma=gamma[j])
          errorMat[i,j]=mean(Response != predictRegDA(Input,out))
        }
        if(CV){
          source("E:/R Project/toolkits/ModelAssessment&Selection.R")
          out=crossValidate(Input,Response,type = "RegDA",complexity = c(alpha[i],gamma[j]),scaleInputs = cvScale,scaleType = "Standardize")
          errorMat[i,j]=mean(out$errorVector)
          stderr[i,j]=out$sdVal
        }
      }
    }
    minInd=which(error==min(error),arr.ind = TRUE)
    i0=minInd[1]
    j0=minInd[2]
    out1=RegDAfit(Input,Response,alpha = alpha[i0],gamma=gamma[j0])
  }
  yhat=predictRegDA(Input,out1)
  error=mean(yhat != Response)
  return(list(yhat=yhat,error=error,alphaVal=alpha[i0],gammaVal=gamma[j0],modRegda=out1))
}

#RRDA classifier
RRDAfit <- function(Input,Response,sub=NULL,modelF=FALSE){
  
  Input=as.matrix(Input)
  N=nrow(Input)
  p=ncol(Input)
  K=length(unique(Response))
  classes=sort(unique(yTrain))
  error=c()
  yHatTrainMat=matrix()
  yHatTrain=c()

  if(is.null(sub)){modelF=TRUE}
  #initiate variables
  Mu_k=matrix(0,nrow = K,ncol = p)#centroid vectors
  Pi_k=vector(length= K)# classes a priori
  sigma=matrix(0,nrow=p,ncol=p)# within class common covariance 
  mu=colMeans(Mu_k)#general mean
  B=matrix(0,ncol=p,nrow = p) #between class covariance B
  
  #compute variables in features space
  for (i in 1:K){
    tmp=Input[Response==classes[i],]
    N0=nrow(tmp)
    Pi_k[i]=N0/N
    Mu_k[i,]=colMeans(tmp)
    for(j in 1:N0){
      sigma=sigma+(tmp[j,]-Mu_k[i,])%*%t(tmp[j,]-Mu_k[i,])}
  }
  sigma=(1/(N-K))*sigma#within class covariance
  for(i in 1:nrow(Mu_k)){
    B=B+Pi_k[i]*(Mu_k[i,]-mu)%*%t(Mu_k[i,]-mu)
  }#between class covariance
  
  #Sphere data w.r.t sigma 
  e=eigen(sigma)#sigma=V*D*t(V)
  U=e$vectors
  D=diag(e$values)
  W_minus_half=U%*%diag(sqrt(e$values)^(-1))
  Mstar=Mu_k%*%W_minus_half
  Inputstar=Input%*%W_minus_half
  Bstar=t(W_minus_half)%*%B%*%W_minus_half
  
  #extract eigen vectors of Bstar
  e2=eigen(Bstar)
  V=e2$vector
  
  #Project into canonical base
  InputTrainCan=Inputstar%*%V
  MeanCan=Mstar%*%V
  canonicalMatrix=W_minus_half%*%V
  #train classifier
  deltaTrain=list()

  if(modelF){
    yHatTrainMat=matrix(nrow = nrow(Input),ncol = p)
    for(subspace in 1:p){
      deltaTrain[[subspace]]=matrix(0,ncol=K,nrow=N)
      for (i in 1:K){
        for (m in 1:N){
          deltaTrain[[subspace]][m,i]=0.5*sum((InputTrainCan[m,1:subspace]-MeanCan[i,1:subspace])^2)-log(Pi_k[i])
        }
      }
      yHatTrainMat[,subspace]=apply(deltaTrain[[subspace]],1,which.min)
      error[subspace]=mean(yHatTrainMat[,subspace] != Response)
    }
    sub=which.min(error)
    yHatTrain=yHatTrainMat[,sub]
  }
  
  if(!modelF){
    deltaTrain[[1]]=matrix(0,ncol=K,nrow=N)
    for (i in 1:K){
      for (m in 1:N){
        deltaTrain[[1]][m,i]=0.5*sum((InputTrainCan[m,1:sub]-MeanCan[i,1:sub])^2)-log(Pi_k[i])
      }
    }
    yHatTrain=apply(deltaTrain[[1]],1,which.min)
  }
  return(list(yHatTrain=yHatTrain,error=error,sub=sub,canonicalMeans=MeanCan,canonicalMat=canonicalMatrix,Pi_k=Pi_k,canonicalTrainData=InputTrainCan))
}
#RRDA prediction
predictRRDA<-function(Input,modRRDA){

  #load model parameters
  sub=modRRDA$sub
  meancan=modRRDA$canonicalMeans
  Pi_k=modRRDA$Pi_k
  canonicalMatrix=as.matrix(modRRDA$canonicalMat)
  K=length(Pi_k)
  #discriminant matrix
  N=nrow(Input)
  canonicalInput=as.matrix(Input)%*%canonicalMatrix
  discrMat=matrix(0,ncol=K,nrow = N)
  
  for (i in 1:K){
    for (m in 1:N){
      discrMat[m,i]=0.5*sum((canonicalInput[m,1:sub]-meancan[i,1:sub])^2)-log(Pi_k[i])
    }
  }
  yHat=apply(discrMat,1,which.min)
  return(yHat)
}

#RRDA model build
RRDA<-function(Input,Response,sub=NULL,CV=FALSE,cvScale=FALSE){
  
  #init parameters:
  error=c()
  errorMat=c()#selection error matrix
  yhat=c()#training prediction
  stderr=c()#standard deviations for CV
  if(!is.null(sub)){
    out=RRDAfit(Input,Response,sub = sub,modelF=FALSE)
  }
  if(is.null(sub)){
    if(!CV){
      out0=RRDAfit(Input,Response,modelF=TRUE)
      sub=out0$sub
      out=RRDAfit(Input,Response,sub=sub,modelF=FALSE)
    }
    if(CV){
      source("D:/RProject/toolkits/ModelAssessment&Selection.R")
      p=ncol(Input)
      for(i in 1:p){
        out0=crossValidate(Input,Response,type="RRDA",complexity = i,scaleInputs = cvScale,scaleType = "Standardize")
        errorMat[i]=mean(out$errorVector)
        stderr[i]=out$sdVal
      }
      sub=which.min(error)
      out=RRDAfit(Input,Response,sub=sub,modelF=FALSE)
    }
  }
  canonicalMeans=out$canonicalMeans
  Pi_k=out$Pi_k
  canonicalMatrix=out$canonicalMat
  sub=out$sub
  yhat=predictRRDA(Input,out)
  error=mean(yhat != Response)
  return(list(yhat=yhat,error=error,errorMat=errorMat,stderr=stderr,sub=sub,canonicalMatrix=canonicalMatrix,Pi_k=Pi_k,canonicalMeans=canonicalMeans))
}

#data reduction visualisation
visualizeReduced<-function(Input,resp,modRRDA,coord1=1,coord2=2){
  Input=as.matrix(Input)
  #load model parameters
  if(!is.null(modRRDA$modRRDA)){modRRDA=modRRDA$modRRDA}
  meancan=modRRDA$canonicalMeans
  canonicalMatrix=modRRDA$canonicalMat
  canonicalInput=Input%*%canonicalMatrix
  Pi_k=modRRDA$Pi_k
  K=length(Pi_k)
  
  #plot.new()
  K=length(unique(resp))
  plot_colors = c("black","blue","brown","purple","orange","cyan","gray","yellow","black","red","green")
  for( j in 1:K ){
    inds = resp == j
    if( j==1 ){
      plot(canonicalInput[inds,coord1], canonicalInput[inds,coord2], xlab=paste("Coordinate",coord1,"for Training Data"), ylab=paste("Coordinate",coord2,"for Training Data"), col=plot_colors[j], type="p", xlim=range(canonicalInput[,coord1]), ylim=range(canonicalInput[,coord2]))	      
      lines(meancan[j,coord1], meancan[j,2], col=plot_colors[j], type="p", cex=10, pch="." )
    }else{
      lines(canonicalInput[inds,coord1], canonicalInput[inds,coord2],type="p" , col=plot_colors[j])
      lines(meancan[j,coord1], meancan[j,coord2], col=plot_colors[j], type="p", cex=10, pch="." )    
    }
  }
  
}


#flexible discriminant analysis
# FlexDA<-function{
# }